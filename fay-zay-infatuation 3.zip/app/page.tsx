"use client"

import VirtualPhotoBooth from "../components/virtual-photo-booth"

export default function SyntheticV0PageForDeployment() {
  return <VirtualPhotoBooth />
}